$(document).ready( function(){
$('#auto').load('marks_load.php');
refresh();
});
 


