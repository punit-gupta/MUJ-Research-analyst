$(document).ready( function(){
$('#auto').load('personaldata_load.php');
refresh();
});
 


