$(document).ready( function(){
$('#auto').load('cgpa_load.php');
refresh();
});
 


