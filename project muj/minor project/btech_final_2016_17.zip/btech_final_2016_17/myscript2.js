$(document).ready( function(){
$('#auto').load('finalterm_marks_load.php');
refresh();
});
 


