<?php
$con = mysqli_connect("localhost","root","","btech_final_2016_17");
if(mysqli_connect_errno()){
echo "Database did not connect";
exit();
}
?>