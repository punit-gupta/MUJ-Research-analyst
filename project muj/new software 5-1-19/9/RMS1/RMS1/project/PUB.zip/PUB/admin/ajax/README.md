ajax-box-php
============

Ajax Search box using PHP and MySQL

Download or clone the repository and create any database in PHPMyadmin.

Update the database information in Search.php file.

Run the code via browser.

For live demo click here : http://demo.codeforgeek.com/ajaxbox/
